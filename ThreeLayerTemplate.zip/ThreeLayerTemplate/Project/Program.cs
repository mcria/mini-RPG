﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Welcome to this amazing program");
Menu.Start();
